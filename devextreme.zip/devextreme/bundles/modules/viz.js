/**
 * DevExtreme (bundles/modules/viz.js)
 * Version: 22.2.4
 * Build date: Thu Jan 19 2023
 *
 * Copyright (c) 2012 - 2023 Developer Express Inc. ALL RIGHTS RESERVED
 * Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
 */
"use strict";
require("./core");
module.exports = DevExpress.viz = DevExpress.viz || {};
