/**
* DevExtreme (data/custom_store.d.ts)
* Version: 22.2.4
* Build date: Thu Jan 19 2023
*
* Copyright (c) 2012 - 2023 Developer Express Inc. ALL RIGHTS RESERVED
* Read about DevExtreme licensing here: https://js.devexpress.com/Licensing/
*/
import { FilterDescriptor, GroupDescriptor, LoadOptions } from './index';
import { Options as StoreOptions, Store } from './abstract_store';
import { DxExtendedPromise, DxPromise } from '../core/utils/deferred';

export type Options<
    TItem = any,
    TKey = any,
> = CustomStoreOptions<TItem, TKey>;

export type GroupItem<
    TItem = any,
> = {
  key: any | string | number;
  items: Array<TItem> | Array<GroupItem<TItem>> | null;
  count?: number;
  summary?: Array<any>;
};

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
type ItemsArray<TItem = any> = Array<TItem> | Array<GroupItem<TItem>>;

export type ResolvedData<
    TItem = any,
> =
  | Object
  | ItemsArray<TItem>
  | {
      data: Array<TItem> | Array<GroupItem>;
      totalCount?: number;
      summary?: Array<any>;
      groupCount?: number;
    };

/**
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
type LoadResult<T> = T | DxPromise<T> | PromiseLike<T>;

/**
 * @deprecated Use Options instead
 * @deprecated Attention! This type is for internal purposes only. If you used it previously, please submit a ticket to our {@link https://supportcenter.devexpress.com/ticket/create Support Center}. We will check if there is an alternative solution.
 */
export interface CustomStoreOptions<
    TItem = any,
    TKey = any,
> extends StoreOptions<TItem, TKey> {
    /**
     * Specifies a custom implementation of the byKey(key) method.
     */
    byKey?: ((key: TKey) => PromiseLike<TItem>);
    /**
     * Specifies whether raw data should be saved in the cache. Applies only if loadMode is &apos;raw&apos;.
     */
    cacheRawData?: boolean;
    /**
     * Specifies a custom implementation of the insert(values) method.
     */
    insert?: ((values: TItem) => PromiseLike<TItem>);
    /**
     * Specifies a custom implementation of the load(options) method.
     */
    load: (options: LoadOptions<TItem>) => LoadResult<ResolvedData<TItem>>;
    /**
     * Specifies how data returned by the load function is treated.
     */
    loadMode?: 'processed' | 'raw';
    /**
     * Specifies a custom implementation of the remove(key) method.
     */
    remove?: ((key: TKey) => PromiseLike<void>);
    /**
     * Specifies a custom implementation of the totalCount(options) method.
     */
    totalCount?: ((loadOptions: { filter?: FilterDescriptor | Array<FilterDescriptor>; group?: GroupDescriptor<TItem> | Array<GroupDescriptor<TItem>> }) => PromiseLike<number>);
    /**
     * Specifies a custom implementation of the update(key, values) method.
     */
    update?: ((key: TKey, values: TItem) => PromiseLike<any>);
    /**
     * Specifies whether the store combines the search and filter expressions. Defaults to true if the loadMode is &apos;raw&apos; and false if it is &apos;processed&apos;.
     */
    useDefaultSearch?: boolean;
}
/**
 * The CustomStore enables you to implement custom data access logic for consuming data from any source.
 */
export default class CustomStore<
    TItem = any,
    TKey = any,
> extends Store<TItem, TKey> {
    constructor(options?: Options<TItem, TKey>);
    /**
     * Deletes data from the cache. Takes effect only if the cacheRawData property is true.
     */
    clearRawDataCache(): void;
    /**
     * 
     */
    load(): DxExtendedPromise<ResolvedData<TItem>>;
    /**
     * 
     */
    load(options: LoadOptions<TItem>): DxExtendedPromise<ResolvedData<TItem>>;
}
